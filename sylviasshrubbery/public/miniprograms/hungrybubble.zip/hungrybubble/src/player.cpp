#include <cmath>
#include <time.h>
#include <stdlib.h>

#include "main.hpp"
#include "player.hpp"

Player::Player() {

	restart();

}

void Player::move(char Dir) {

	if (Dir != dir::none) {

		direction = Dir;

	}

	if (!reverse) {

		switch (direction) {

			case dir::up:    y -= speed; break;
			case dir::down:  y += speed; break;
			case dir::right: x += speed; break;
			case dir::left:  x -= speed; break;

		}

	} else {

		switch (direction) {

			case dir::up:    y += speed; break;
			case dir::down:  y -= speed; break;
			case dir::right: x -= speed; break;
			case dir::left:  x += speed; break;

		}

	}

	// Check for wall hits
	if (x - radius < 0) {

		// push it back
		x = radius;

	}

	if (x + radius > WINDOW_WIDTH) {

		x = WINDOW_WIDTH - radius;

	}

	if (y - radius < TOP_MARGIN) {

		// push it back
		y = radius + TOP_MARGIN;

	}

	if (y + radius > WINDOW_HEIGHT) {

		y = WINDOW_HEIGHT - radius;

	}

}

void Player::grow() {

	radius += 2;

	if (radius > 30) {

		radius = 30;

	}

}

void Player::shrink() {
	
	radius -= 2;

	if (radius < 4) {

		radius = 4;

	}

}

void Player::faster() {

	speed += 1;

	if (speed > 10) {

		speed = 10;

	}

}

void Player::slower() {

	speed -= 1;

	if (speed < 1) {

		speed = 1;

	}

}

void Player::reverseKeys() {

	// 
	reverse = !reverse;

}

bool Player::hitTestCircle(int hitX, int hitY, int hitRadius) {

	if (sqrt(pow(hitX - x, 2) + pow(y - hitY, 2)) < (radius + hitRadius)) {

		return true;

	} else {

		return false;

	}

}

bool Player::hitTestSquare(int hitX, int hitY, int hitRadius) {

	// FIXME this needs to test for circle against square
	if ((x + radius >= hitX - hitRadius) && (x - radius <= hitX + hitRadius)
	 && (y + radius >= hitY - hitRadius) && (y - radius <= hitY + hitRadius)) {

		return true;

	} else {

		return false;

	}

}

// Re-initialize the player characteristics
void Player::restart() {

	reverse   = false;
	direction = dir::none;
	radius    = 10;
	x         = WINDOW_WIDTH / 2;
	y         = WINDOW_HEIGHT / 2;
	speed     = 3;

}

