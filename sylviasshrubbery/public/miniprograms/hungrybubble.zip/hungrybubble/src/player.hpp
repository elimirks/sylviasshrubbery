#pragma once

class Player {

	private:

	int radius;
	int x, y;

	int speed;
	int direction;

	// To see if the reverse cookie is in action
	bool reverse;

	public:
	
	Player();

	int getX() { return x; }
	int getY() { return y; }
	
	int getRadius() { return radius; }
	int getSpeed() { return speed; }

	void move(char Dir);
	void restart();
	
	void grow();
	void shrink();

	void slower();
	void faster();

	void reverseKeys();

	bool hitTestCircle(int hitX, int hitY, int hitRadius);
	bool hitTestSquare(int hitX, int hitY, int hitRadius);

};

