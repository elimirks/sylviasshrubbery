#pragma once

class Badguy {

	private:

	int radius;
	int x, y;
	int xSpeed, ySpeed;

	public:

	Badguy(int X, int Y, int XSpeed, int YSpeed);

	int getX() { return x; }
	int getY() { return y; }

	int getRadius() { return radius; }

	void move();

};

