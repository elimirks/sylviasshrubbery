#pragma once

#include <string>
#include <vector>

#include "main.hpp"

std::string itos(int number);
std::string wstos(const std::wstring& to_convert);
bool is_highscore(int score);
void send_score(std::string name, int score);
std::vector<Score> get_scores();

