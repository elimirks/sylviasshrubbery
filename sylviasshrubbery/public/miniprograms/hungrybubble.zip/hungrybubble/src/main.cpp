#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>
#include <iostream>
#include <time.h>
#include <vector>
#include <algorithm>
#include <string>
#include <sstream>
#include <fstream>

#include "main.hpp"
#include "network.hpp"
#include "player.hpp"
#include "cookie.hpp"
#include "badguy.hpp"

// SimpleJSON library
#include "SimpleJSON/JSON.h"

sf::RenderWindow window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Hungry Bubble");

sf::Event event;

Player player;
std::vector<Cookie> cookies;
std::vector<Badguy> badguys;

sf::CircleShape circle;
sf::RectangleShape rect;

sf::Font fontMain;
sf::Text text;

std::vector<MenuButton> menubuttons;
std::vector<Score> scorevec;

MenuButton backbutton = MenuButton{"Back", 10, WINDOW_HEIGHT - 60, 100, 50, false, button::back};

int score;
bool paused;
int current_window = win::menu;
int current_popup  = popup::none;
int popup_color;

std::string name;

int main(int argc, char* argv[]) {

	fontMain.loadFromFile("data/chiser.ttf");
	text.setFont(fontMain);
	
	sf::Clock clock;
	float Framerate;

	window.setFramerateLimit(FRAMERATE);

	// random seed
	srand(time(NULL));

	// Create main menu buttons
	menubuttons.push_back(MenuButton{"Play", WINDOW_WIDTH / 2 - 150 / 2, 170, 150, 50, false, button::play});
	menubuttons.push_back(MenuButton{"Scores", menubuttons.back().x, menubuttons.back().y + menubuttons.back().height, menubuttons.back().width, menubuttons.back().height, false, button::scores});
	menubuttons.push_back(MenuButton{"Help", menubuttons.back().x, menubuttons.back().y + menubuttons.back().height, menubuttons.back().width, menubuttons.back().height, false, button::help});
	menubuttons.push_back(MenuButton{"Credits", menubuttons.back().x, menubuttons.back().y + menubuttons.back().height, menubuttons.back().width, menubuttons.back().height, false, button::credits});
	menubuttons.push_back(MenuButton{"Quit", menubuttons.back().x, menubuttons.back().y + menubuttons.back().height, menubuttons.back().width, menubuttons.back().height, false, button::quit});

	// Create cookies
	cookies.push_back(Cookie(Cookie::Grow));
	cookies.push_back(Cookie(Cookie::Shrink));
	cookies.push_back(Cookie(Cookie::Speed));
	cookies.push_back(Cookie(Cookie::Slow));
	cookies.push_back(Cookie(Cookie::Reverse));

	// Randomize the cookies
	for (Cookie& i : cookies) {

		i.flip();

	}

	// Main loop
	while (window.isOpen()) {
		
		// Update the fremerate
		Framerate = 1.f / clock.getElapsedTime().asSeconds();
		
		// Sift through events
		while (window.pollEvent(event)) {

			if (event.type == sf::Event::Closed) {

				window.close();

			} else if (event.type == sf::Event::KeyPressed) {

				if (event.key.code == sf::Keyboard::P || event.key.code == sf::Keyboard::Escape) {

					if (current_popup == popup::pause) {

						current_popup = popup::none;

					} else if (current_popup == popup::none) {

						current_popup = popup::pause;

					}

				}
			
			} else if (event.type == sf::Event::TextEntered) {
	
				if (current_popup == popup::win) {

					// Enable backspacing
					if (event.text.unicode == 8) {

						if (name.size() > 0) {

							name.resize(name.size() - 1);
			
						}
					
					// Enter key to submit
					} else if (event.text.unicode == 13) {

						send_score(name, score);
						current_popup = popup::lose;

					// Handle ASCII characters only
					} else if (event.text.unicode < 128) {

						if (name.size() < 20) {

							name += static_cast<char>(event.text.unicode);

						}

					}

				} else if (current_popup == popup::lose || current_popup == popup::pause) {

					// M character
					if (event.text.unicode == 0x6d) {

						current_window = win::menu;

					}
					
					if (current_popup == popup::lose) {

						// P character
						if (event.text.unicode == 0x70) {

							restart();

						}

					}

				}
			
			}

		}
	
		if (current_window == win::menu) {

			// Mouse collisions (aka, hovering)

			for (MenuButton& i : menubuttons) {

				if (sf::Mouse::getPosition(window).x > i.x && sf::Mouse::getPosition(window).x < i.x + i.width
				 && sf::Mouse::getPosition(window).y > i.y && sf::Mouse::getPosition(window).y < i.y + i.height) {

					if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {

						if (i.type == button::quit) {

							window.close();

						} else if (i.type == button::play) {

							current_window = win::game;
							restart();

						} else if (i.type == button::scores) {
	
							current_window = win::highscores;
							scorevec.clear();

						} else if (i.type == button::help) {
	
							current_window = win::help;

						} else if (i.type == button::credits) {
	
							current_window = win::credits;

						}

					}

					i.hovered = true;

				} else {

					i.hovered = false;

				}

			}

			// Drawing board
			
			window.clear();

			text.setStyle(sf::Text::Regular);

			text.setColor(sf::Color::White);
			
			text.setString(sf::String("Hungry Bubble"));
			text.setCharacterSize(40);
			text.setPosition(WINDOW_WIDTH / 2 - text.getLocalBounds().width / 2, 30);
			
			window.draw(text);
			
			text.setStyle(sf::Text::Regular);
			
			text.setString(sf::String("Version 1.1"));
			text.setCharacterSize(12);
			text.setPosition(WINDOW_WIDTH - text.getLocalBounds().width - 5, WINDOW_HEIGHT - text.getLocalBounds().height - 10);

			window.draw(text);

			rect.setFillColor(sf::Color(0x00, 0x00, 0x00));
			rect.setOutlineColor(sf::Color(0xff, 0xff, 0xff));
			rect.setOutlineThickness(2);
			text.setCharacterSize(30);

			// Sift through the menu buttons and draw them
			for (MenuButton i : menubuttons) {

				rect.setSize(sf::Vector2f(i.width, i.height));
				rect.setPosition(i.x, i.y);

				if (i.hovered) {

					rect.setFillColor(sf::Color(0x22, 0x22, 0x22));

				} else {

					rect.setFillColor(sf::Color(0x00, 0x00, 0x00));

				}

				window.draw(rect);

				text.setString(sf::String(i.label));
				text.setPosition(WINDOW_WIDTH / 2 - text.getLocalBounds().width / 2, rect.getPosition().y + 5);

				window.draw(text);

			}

		} else if (current_window == win::game) {
			
			// All the main actions go here
			if (!paused) {

				// Player controls

				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {

					player.move(dir::up);

				} else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {

					player.move(dir::down);

				} else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {

					player.move(dir::left);

				} else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {

					player.move(dir::right);

				} else {

					player.move(dir::none);

				}

				for (Badguy& i : badguys) {

					i.move();

					// Test for badguy hits and kill the player
					if (player.hitTestCircle(i.getX(), i.getY(), i.getRadius())) {

						current_popup = popup::die;

					}

				}

				// Hit testing

				for (Cookie& i : cookies) {
		
					i.move();

					if (player.hitTestCircle(i.getX(), i.getY(), i.getRadius())) {

						switch (i.getType()) {

							case Cookie::Grow:
								player.grow();
							break;
							
							case Cookie::Shrink:
								player.shrink();
							break;
							
							case Cookie::Speed:
								player.faster();
							break;
							
							case Cookie::Slow:
								player.slower();
							break;
							
							case Cookie::Reverse:
								player.reverseKeys();
							break;

						}

						score++;

						// Randomly move the cookie
						i.flip();
				
						// The badguys always come from the side further away from the player
						if (player.getX() >= WINDOW_WIDTH / 2) {

							badguys.push_back(Badguy(-5, rand() % WINDOW_HEIGHT, 1 + rand() % 3, 1 + rand() % 3));
			
						} else {

							badguys.push_back(Badguy(WINDOW_WIDTH + 5, rand() % WINDOW_HEIGHT, 1 + rand() % 3, 1 + rand() % 3));

						}

					}

				}

			}

			// Drawing board

			window.clear();

			for (Cookie& i : cookies) {

				circle.setRadius(i.getRadius());

				circle.setPosition(i.getX() - i.getRadius(), i.getY() - i.getRadius());

				switch (i.getType()) {

					case Cookie::Grow:
						circle.setFillColor(sf::Color(0xff, 0x00, 0x00));
					break;

					case Cookie::Shrink:
						circle.setFillColor(sf::Color(0x00, 0xff, 0x00));
					break;

					case Cookie::Speed:
						circle.setFillColor(sf::Color(0xff, 0x66, 0x00));
					break;

					case Cookie::Slow:
						circle.setFillColor(sf::Color(0x66, 0x66, 0xff));
					break;

					case Cookie::Reverse:
						circle.setFillColor(sf::Color(0xff, 0x00, 0xff));
					break;

				}

				window.draw(circle);
			
			}

			// Draw bad guys
			for (Badguy &i : badguys) {

				circle.setRadius(i.getRadius());
				circle.setPosition(i.getX() - i.getRadius(), i.getY() - i.getRadius());
				circle.setFillColor(sf::Color(0xff, 0xff, 0xff));

				window.draw(circle);

			}

			circle.setRadius(player.getRadius());
			circle.setPosition(player.getX() - player.getRadius(), player.getY() - player.getRadius());
			circle.setFillColor(sf::Color(0xff, 0xff, 0x00));

			window.draw(circle);

			// Draw the top menu bar

			rect.setPosition(0, TOP_MARGIN);
			rect.setFillColor(sf::Color::White);
			rect.setSize(sf::Vector2f(WINDOW_WIDTH, 1));
			rect.setOutlineThickness(0);
			
			window.draw(rect);

			text.setCharacterSize(14);
			text.setStyle(sf::Text::Regular);
			text.setColor(sf::Color::White);

			text.setString(sf::String("Score: " + itos(score)));
			text.setPosition(5, -3);
			
			window.draw(text);

			text.setString(sf::String("Speed: " + itos(player.getSpeed())));
			text.setPosition(105, -3);

			window.draw(text);

			text.setString(sf::String("Size: " + itos(player.getRadius() / 2)));
			text.setPosition(205, -3);

			window.draw(text);

			// Popup handeling

			if (current_popup == popup::none) {

				paused = false;
				window.setMouseCursorVisible(false);

				popup_color = rand() % 4;

			} else {

				paused = true;
				window.setMouseCursorVisible(true);
			
				// Randomize the colors every time there is a popup
				if (popup_color == 0) {

					rect.setFillColor(sf::Color(0x66, 0xff, 0x66, 0xbb));
					rect.setOutlineColor(sf::Color(0x33, 0xaa, 0x33, 0xbb));
				
				} else if (popup_color == 1) {

					rect.setFillColor(sf::Color(0xff, 0x66, 0x66, 0xbb));
					rect.setOutlineColor(sf::Color(0xaa, 0x33, 0x33, 0xbb));

				} else if (popup_color == 2) {

					rect.setFillColor(sf::Color(0x66, 0x66, 0xff, 0xbb));
					rect.setOutlineColor(sf::Color(0x33, 0x33, 0xaa, 0xbb));
				
				} else if (popup_color == 3) {

					rect.setFillColor(sf::Color(0xff, 0xff, 0x66, 0xbb));
					rect.setOutlineColor(sf::Color(0xaa, 0xaa, 0x33, 0xbb));

				}

				rect.setOutlineThickness(10);

				rect.setSize(sf::Vector2f(300, 200));
				rect.setPosition(WINDOW_WIDTH / 2 - rect.getSize().x / 2, WINDOW_HEIGHT / 2 - rect.getSize().y / 2);

				window.draw(rect);

				if (current_popup == popup::pause) {

					text.setStyle(sf::Text::Regular);
					text.setColor(sf::Color::White);

					text.setCharacterSize(40);
					text.setPosition((((rect.getPosition().x * 2) + rect.getSize().x) / 2) - text.getLocalBounds().width / 2,
					rect.getPosition().y + 50);

					text.setString(sf::String("Paused"));

					window.draw(text);

					text.setColor(sf::Color::Black);
					text.setPosition(text.getPosition().x - 1, text.getPosition().y - 1);
					
					window.draw(text);

					text.setColor(sf::Color::White);
					text.setStyle(sf::Text::Regular);
					
					text.setCharacterSize(20);
					text.setString(sf::String("Press P to resume\nPress M to go the menu"));
					text.setPosition((((rect.getPosition().x * 2) + rect.getSize().x) / 2) - text.getLocalBounds().width / 2,
					rect.getPosition().y + rect.getSize().y - text.getLocalBounds().height - 20);

					window.draw(text);

					text.setColor(sf::Color::Black);
					text.setPosition(text.getPosition().x - 1, text.getPosition().y - 1);

					window.draw(text);

				} else if (current_popup == popup::die) {

					text.setStyle(sf::Text::Regular);
					text.setColor(sf::Color::White);

					text.setCharacterSize(40);
					text.setString(sf::String("Loading..."));
					text.setPosition((((rect.getPosition().x * 2) + rect.getSize().x) / 2) - text.getLocalBounds().width / 2,
					rect.getPosition().y + 70);

					window.draw(text);

					text.setColor(sf::Color::Black);
					text.setPosition(text.getPosition().x - 1, text.getPosition().y - 1);
					
					window.draw(text);

					// Why we have to call this now is because loading the highscores may take some time
					window.display();

					if (is_highscore(score)) {

						current_popup = popup::win;
						name = "";

					} else {

						current_popup = popup::lose;

					}

				} else if (current_popup == popup::lose) {

					text.setStyle(sf::Text::Regular);
					text.setColor(sf::Color::White);

					text.setCharacterSize(40);
					text.setString(sf::String("You got hit!"));
					text.setPosition((((rect.getPosition().x * 2) + rect.getSize().x) / 2) - text.getLocalBounds().width / 2,
					rect.getPosition().y + 40);

					window.draw(text);

					text.setColor(sf::Color::Black);
					text.setPosition(text.getPosition().x - 1, text.getPosition().y - 1);
					
					window.draw(text);

					text.setColor(sf::Color::White);
					text.setStyle(sf::Text::Regular);
					
					text.setCharacterSize(20);
					text.setString(sf::String("Press P to play again\nPress M to go the menu"));
					text.setPosition((((rect.getPosition().x * 2) + rect.getSize().x) / 2) - text.getLocalBounds().width / 2,
					rect.getPosition().y + rect.getSize().y - text.getLocalBounds().height - 20);

					window.draw(text);

					text.setColor(sf::Color::Black);
					text.setPosition(text.getPosition().x - 1, text.getPosition().y - 1);

					window.draw(text);

				} else if (current_popup == popup::win) {

					// Draw the name

					text.setString(name);
					text.setStyle(sf::Text::Regular);
					text.setColor(sf::Color::White);
					text.setPosition((((rect.getPosition().x * 2) + rect.getSize().x) / 2) - text.getLocalBounds().width / 2,
					rect.getPosition().y + 100);

					window.draw(text);

					text.setColor(sf::Color::Black);
					text.setPosition(text.getPosition().x - 1, text.getPosition().y - 1);
					
					window.draw(text);

					//

					text.setStyle(sf::Text::Regular);
					text.setColor(sf::Color::White);

					text.setCharacterSize(30);
					text.setString(sf::String("You got a high score!"));
					text.setPosition((((rect.getPosition().x * 2) + rect.getSize().x) / 2) - text.getLocalBounds().width / 2,
					rect.getPosition().y + 10);

					window.draw(text);

					text.setColor(sf::Color::Black);
					text.setPosition(text.getPosition().x - 1, text.getPosition().y - 1);
					
					window.draw(text);

					text.setStyle(sf::Text::Regular);
					text.setColor(sf::Color::White);

					text.setCharacterSize(20);
					text.setString(sf::String("Enter your name\n(Press Enter to submit)"));
					text.setPosition((((rect.getPosition().x * 2) + rect.getSize().x) / 2) - text.getLocalBounds().width / 2,
					rect.getPosition().y + 50);

					window.draw(text);

					text.setColor(sf::Color::Black);
					text.setPosition(text.getPosition().x - 1, text.getPosition().y - 1);
					
					window.draw(text);
				
				}
			
			}

		} else {
			
			window.clear();
			
			if (sf::Mouse::getPosition(window).x > backbutton.x && sf::Mouse::getPosition(window).x < backbutton.x + backbutton.width
			 && sf::Mouse::getPosition(window).y > backbutton.y && sf::Mouse::getPosition(window).y < backbutton.y + backbutton.height) {

				if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {

					if (backbutton.type == button::back) {

						current_window = win::menu;

					}

				}

				rect.setFillColor(sf::Color(0x22, 0x22, 0x22));

			} else {

				rect.setFillColor(sf::Color(0x00, 0x00, 0x00));
			
			}

			rect.setSize(sf::Vector2f(backbutton.width, backbutton.height));
			rect.setPosition(backbutton.x, backbutton.y);

			window.draw(rect);

			text.setCharacterSize(30);
			text.setString(sf::String(backbutton.label));
			text.setPosition((((rect.getPosition().x * 2) + rect.getSize().x) / 2) - text.getLocalBounds().width / 2,
			rect.getPosition().y + 5);
			
			window.draw(text);

			if (current_window == win::highscores) {
			
				text.setStyle(sf::Text::Regular);

				if (scorevec.size() == 0) {

					text.setCharacterSize(50);
					text.setString(sf::String("Loading..."));
					text.setPosition(WINDOW_WIDTH / 2 - (text.getLocalBounds().left + text.getLocalBounds().width / 2),
					WINDOW_HEIGHT / 2 - (text.getLocalBounds().top + text.getLocalBounds().height / 2));
					
					window.draw(text);
				
					window.display();

					scorevec = get_scores();

				} else {

					text.setCharacterSize(40);
					text.setString("Hall of Fame");
					text.setPosition(WINDOW_WIDTH / 2 - (text.getLocalBounds().left + text.getLocalBounds().width / 2), 20);

					window.draw(text);
					
					text.setCharacterSize(20);
					text.setPosition(WINDOW_WIDTH / 2 - (text.getLocalBounds().left + text.getLocalBounds().width / 2), 50);
					
					for (Score i : scorevec) {

						text.setString(sf::String(i.name));
						text.setPosition(WINDOW_WIDTH / 2 - (text.getLocalBounds().left + text.getLocalBounds().width / 2) - 100, text.getGlobalBounds().top + text.getGlobalBounds().height + 5);

						window.draw(text);

						text.setString(sf::String(itos(i.amount)));
						text.setPosition(WINDOW_WIDTH / 2 - (text.getLocalBounds().left + text.getLocalBounds().width / 2) + 100, text.getGlobalBounds().top);

						window.draw(text);

					}

				}

			} else if (current_window == win::help) {
					
				text.setCharacterSize(40);
				text.setString("Help");
				text.setPosition(WINDOW_WIDTH / 2 - (text.getLocalBounds().left + text.getLocalBounds().width / 2), 20);

				window.draw(text);
				
				text.setCharacterSize(20);
				text.setString("Movement: arrow keys\nP to pause\n\nEat the colored circles to get points\nEach color affects you differently");
				text.setPosition(WINDOW_WIDTH / 2 - (text.getLocalBounds().left + text.getLocalBounds().width / 2), 100);
				
				window.draw(text);

			} else if (current_window == win::credits) {
				
				text.setCharacterSize(40);
				text.setString("Credits");
				text.setPosition(WINDOW_WIDTH / 2 - (text.getLocalBounds().left + text.getLocalBounds().width / 2), 20);

				window.draw(text);
				
				text.setCharacterSize(30);
				text.setString("Game created by Eliasz (Elijah) Mirecki.");
				text.setPosition(WINDOW_WIDTH / 2 - (text.getLocalBounds().left + text.getLocalBounds().width / 2), 200);
				
				window.draw(text);

			}

		}

		window.display();

	}

	return 0;

}

// Re-initialize the playing field
void restart() {

	paused        = false;
	score         = 0;
	current_popup = popup::none;

	for (Cookie& i : cookies) {

		i.flip();

	}
	
	badguys.clear();
	player.restart();

}

