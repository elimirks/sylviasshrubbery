#include "main.hpp"
#include "badguy.hpp"

Badguy::Badguy(int X, int Y, int XSpeed, int YSpeed) {

	xSpeed = XSpeed;
	ySpeed = YSpeed;

	x = X;
	y = Y;

	radius = 6;

}

void Badguy::move() {

	if ((x - radius < 0) && (xSpeed < 0)) {

		xSpeed -= xSpeed * 2;

	}

	if ((x + radius > WINDOW_WIDTH) && (xSpeed > 0)) {

		xSpeed -= xSpeed * 2;

	}

	if ((y - radius < TOP_MARGIN) && (ySpeed < 0)) {

		ySpeed -= ySpeed * 2;

	}

	if ((y + radius > WINDOW_HEIGHT) && (ySpeed > 0)) {

		ySpeed -= ySpeed * 2;

	}

	x += xSpeed;
	y += ySpeed;

}

