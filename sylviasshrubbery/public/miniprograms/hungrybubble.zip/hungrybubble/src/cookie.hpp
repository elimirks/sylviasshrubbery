#ifndef COOKIE_HPP
#define COOKIE_HPP

class Cookie {

	private:

	int x, y;
	int radius;
	int type;

	public:

	enum CookieTypes {
		Grow,
		Shrink,
		Speed,
		Slow,
		Reverse,
	};

	Cookie(int Type);
	
	// Move the cookie to a random place
	void flip();

	// This could be implemented later if we want the cookies to move 
	void move();

	// Getters

	int getX()      { return x;       }
	int getY()      { return y;       }
	int getRadius() { return radius;  }
	int getType()   { return type;    }

};

#endif

