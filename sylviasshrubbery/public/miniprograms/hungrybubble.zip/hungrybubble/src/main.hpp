#pragma once

#include <string>

// 720p
#define WINDOW_WIDTH 720
#define WINDOW_HEIGHT 576

// These are for if there will be a manu bar on any of the sides
#define TOP_MARGIN 15
#define BOTTOM_MARGIN 0
#define LEFT_MARGIN 0
#define RIGHT_MARGIN 0

#define FRAMERATE 45

struct Score {

	std::string name;
	int amount;

};

struct MenuButton {

	std::string label;
	int x, y;
	int width, height;
	bool hovered;
	int type;

};

namespace loadstat {

	enum {
		yes,
		no,
		loading,
		nostart,
	};

}

namespace dir {

	enum {
		up,
		down,
		right,
		left,
		none,
	};

}

namespace button {

	enum {
		play,
		scores,
		help,
		credits,
		quit,
		back,
	};

}

namespace win {

	enum {
		menu,
		game,
		highscores,
		help,
		credits,
	};

}

namespace popup {

	enum {
		pause,
		die,
		win,
		lose,
		none,
	};

}

void restart();

