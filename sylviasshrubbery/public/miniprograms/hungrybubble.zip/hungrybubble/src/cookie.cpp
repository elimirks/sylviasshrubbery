#include <time.h>
#include <stdlib.h>

#include "main.hpp"
#include "cookie.hpp"

Cookie::Cookie(int Type) {

	x      = 0;
	y      = 0;
	radius = 0;
	type   = Type;

}

void Cookie::flip() {

	radius = 0;

	// Randomize position
	x = 3 + rand() % (WINDOW_WIDTH - 6);
	y = 3 + TOP_MARGIN + rand() % (WINDOW_HEIGHT - 6 - TOP_MARGIN), 6, 'r';

}

void Cookie::move() {

	if (radius < 5) {

		radius++;

	}

}

