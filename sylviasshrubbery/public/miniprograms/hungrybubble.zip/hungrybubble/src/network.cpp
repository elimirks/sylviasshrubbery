#include <SFML/Network.hpp>
#include <string>
#include <vector>
#include <sstream>
#include <iostream>

#include "main.hpp"
#include "network.hpp"

// SimpleJSON library
#include "SimpleJSON/JSON.h"

std::string itos(int number) {

	// Create a stringstream
	std::stringstream ss;

	// Add number to the stream
	ss << number;

	// Return a string with the contents of the stream
	return ss.str();

}

std::string wstos(const std::wstring& to_convert) {

	std::string temp(to_convert.length(), ' ');

	// Copy the wstring over while cutting off the first and last characters (quotation marks)
	std::copy(to_convert.begin() + 1, to_convert.end() - 1, temp.begin());
	
	return temp;

}

bool is_highscore(int score) {

	// Create a new HTTP client
	sf::Http http;
	http.setHost("http://elijah.mirecki.com");
	sf::Http::Request request("games/hungrybubble/is_highscore.php");
	request.setMethod(sf::Http::Request::Method::Post);
	request.setBody("score=" + itos(score));

	sf::Http::Response response = http.sendRequest(request);

	sf::Http::Response::Status status = response.getStatus();

	if (status == sf::Http::Response::Ok) {

		size_t found;

		found = response.getBody().find("true");

		if (found != std::string::npos) {

			return true;

		} else {

			return false;

		}
	
	} else {

		std::cout << "Error " << status << "! Could not connect to the interwebs!" << std::endl;
		return false;

	}

}

void send_score(std::string name, int score) {

	// Create a new HTTP client
	sf::Http http;

	http.setHost("http://elijah.mirecki.com");

	// Prepare to send
	sf::Http::Request request("games/hungrybubble/send_score.php");
	request.setMethod(sf::Http::Request::Method::Post);
	request.setBody("name=" + name + "&score=" + itos(score));

	// Send request 
	sf::Http::Response response = http.sendRequest(request);

	// Check the status code and display the result
	sf::Http::Response::Status status = response.getStatus();

	if (status == sf::Http::Response::Ok) {

		std::cout << "Score of " << score << " submitted successfully!\n";
		
	} else {

		std::cout << "Error " << status << "! Could not connect to the interwebs!\n";
		
	}

}

std::vector<Score> get_scores() {

	std::vector<Score> scores;

	// Create a new HTTP client
	sf::Http http;

	http.setHost("http://elijah.mirecki.com");

	// Prepare to send
	sf::Http::Request request("games/hungrybubble/get_scores.php");

	// Send request 
	sf::Http::Response response = http.sendRequest(request);

	// Check the status code and display the result
	sf::Http::Response::Status status = response.getStatus();

	if (status == sf::Http::Response::Ok) {

		JSONValue* value = JSON::Parse(response.getBody().c_str());

		if (value == NULL) {

			std::cout << "Failed to parse JSON data!\n";

		} else {
		
			JSONObject root;
			root = value->AsObject();

			if (root[L"scores"]->IsArray()) {

				JSONArray array = root[L"scores"]->AsArray();

				for (unsigned short i = 0; i < array.size(); i++) {
					
					Score tmpscore;

					JSONObject newroot;
					newroot = array[i]->AsObject();

					tmpscore.name   = wstos(newroot[L"name"]->Stringify());
					tmpscore.amount = atoi(wstos(newroot[L"score"]->Stringify()).c_str());

					scores.push_back(tmpscore);

				}

			}

		}

	} else {

		std::cout << "Error " << status << "! Could not connect to the interwebs!" << std::endl;
		scores.push_back(Score{"Failed to connect!", 0});

	}

	return scores;

}

