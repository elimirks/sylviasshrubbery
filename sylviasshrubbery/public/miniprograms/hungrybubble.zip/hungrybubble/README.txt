Hello all!

To play:

Windows -- hungrybubble.exe
 - Should work out of the box
 - Run as hungrybubble.bat
Linux   -- hungrybubble
 - May need the SFML2 libraries installed
 - Run as hungrybubble.sh
Mac     -- (hungrybubble might work.. or the bat file using win)

RULES:

Cookies do magical things.. you could figure it out
The badguys come every time you eat a cookie, from the horizontal side further from you

CONTROLS:

Arrow keys to move

LASTLY:

Enjoy!

