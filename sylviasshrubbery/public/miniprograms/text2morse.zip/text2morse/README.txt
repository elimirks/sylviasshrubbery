Input is through stdin. You are able to pipe input to this program, or type followed with an EOF char (Ctrl-D).
SDL is needed for compilation.

