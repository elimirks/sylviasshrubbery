// SDL has a good audio API
#include "SDL.h"
#include "SDL_mixer.h"

#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>

#define PAUSE_TIME 400000

Mix_Chunk* low_sample  = NULL;
Mix_Chunk* high_sample = NULL;

// Use an 8 bit binary number for the sequence, not a vector... that would be cooler :)
// Use a second 8 bit number to determine the length of the sequence
// The set_sequence should have 2 arguments. 1) the 8 bit number. 2) the amount of bits to use in the sequence
struct Character {
	uint8_t sequence;
	uint8_t length;
};

// Letters + numbers.
struct Character alphabet[36];

struct Character createCharacter(uint8_t p_sequence, uint8_t p_length) {
	struct Character f_character;
	f_character.sequence = p_sequence;
	f_character.length = p_length;
	return f_character;
}

void play_sample(Mix_Chunk* sample) {
	// channel = next free, chuck = parameter, loops = 0, ticks = 50 (ms)
	if (Mix_PlayChannelTimed(-1, sample, 0, 70) == -1) {
		printf("Mix_PlayChannel: %s\n", Mix_GetError());
	}
}

// Later this will have to make sound.
void play(struct Character character) {
	uint8_t f_position = character.length;
	
	while (f_position-- > 0) {
		// Bit shifting magic!
		// AND the character sequence with 1 shifted left to the f_position to check if the bit is set or not.
		// character.sequence & (1 << f_position)
		if (character.sequence & 1 << f_position) {
			printf("%d\n", 1);
			play_sample(high_sample);
		} else {
			printf("%d\n", 0);
			play_sample(low_sample);
		}
		usleep(PAUSE_TIME);
	}
	// Give a short pause between characters
	usleep(PAUSE_TIME);
}

void populate_alphabet() {
	// A
	alphabet[0] = createCharacter(0b00000001, 2);
	alphabet[1] = createCharacter(0b00001000, 4);
	alphabet[2] = createCharacter(0b00001010, 4);
	alphabet[3] = createCharacter(0b00000100, 3);
	alphabet[4] = createCharacter(0b00000000, 1);
	alphabet[5] = createCharacter(0b00000010, 4);
	alphabet[6] = createCharacter(0b00000110, 3);
	// H
	alphabet[7] = createCharacter(0b00000000, 4);
	alphabet[8] = createCharacter(0b00000000, 2);
	alphabet[9] = createCharacter(0b00000111, 4);
	alphabet[10] = createCharacter(0b00000101, 3);
	alphabet[11] = createCharacter(0b00000100, 4);
	alphabet[12] = createCharacter(0b00000011, 2);
	alphabet[13] = createCharacter(0b00000010, 2);
	alphabet[14] = createCharacter(0b00000111, 3);
	alphabet[15] = createCharacter(0b00000110, 4);
	// Q
	alphabet[16] = createCharacter(0b00001101, 4);
	alphabet[17] = createCharacter(0b00000010, 3);
	alphabet[18] = createCharacter(0b00000000, 3);
	alphabet[19] = createCharacter(0b00000001, 1);
	alphabet[20] = createCharacter(0b00000001, 3);
	alphabet[21] = createCharacter(0b00000001, 4);
	// W
	alphabet[22] = createCharacter(0b00000011, 3);
	alphabet[23] = createCharacter(0b00001001, 4);
	alphabet[24] = createCharacter(0b00001011, 4);
	alphabet[25] = createCharacter(0b00001100, 4);

	// Numbers 0 + 1-9
	alphabet[26] = createCharacter(0b00011111, 5);
	alphabet[27] = createCharacter(0b00001111, 5);
	alphabet[28] = createCharacter(0b00000111, 5);
	alphabet[29] = createCharacter(0b00000011, 5);
	alphabet[30] = createCharacter(0b00000001, 5);
	alphabet[31] = createCharacter(0b00000000, 5);
	alphabet[32] = createCharacter(0b00010000, 5);
	alphabet[33] = createCharacter(0b00011000, 5);
	alphabet[34] = createCharacter(0b00011100, 5);
	alphabet[35] = createCharacter(0b00011110, 5);
	
	// Now you know your ABCs, next time won't you sing with me :)
}

int load_data() {
	if (SDL_Init(SDL_INIT_AUDIO) == -1) {
		printf("SDL_Init: %s\n", SDL_GetError());
		return 0;
	}
	// open 44.1KHz, signed 16bit, system byte order,
	//      mono audio, using 1024 byte chunks
	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 1, 1024) == -1) {
		printf("Mix_OpenAudio: %s\n", Mix_GetError());
		return 0;
	}
	
	high_sample = Mix_LoadWAV("high.wav");
	low_sample  = Mix_LoadWAV("low.wav");
	
	if (!high_sample) {
		printf("Mix_LoadWAV high_sample: %s\n", Mix_GetError());
		return 0;
	}
	if (!low_sample) {
		printf("Mix_LoadWAV low_sample:  %s\n", Mix_GetError());
		return 0;
	}
	
	return 1;
}

void free_data() {
	free(high_sample);
	free(low_sample);
	Mix_CloseAudio();
	SDL_Quit();
}

int main(int argc, char** argv) {
	if (!load_data()) return 0;
	populate_alphabet();
	
	// This is basically a word space
	// We will use on PAUSE_TIME for characters, 2 for words, and 3 for sentences.
	//usleep(PAUSE_TIME);
	
	printf("Ctrl+D to exit\n\n");
	
	int cur;
	
	// Keep getting characters from stdin
	while (cur = getchar()) {
		// Ctrl+D -- End input
		if (cur == -1) break;
		// These are just things like newlines, CRs, EOL, etc.
		else if (cur >= 0x0 && cur <= 0x1F) continue;
		
		printf("\nPlaying '%c' #%d\n\n", cur, cur);

		// We always want uppercase characters
		if (cur >= 'a' && cur <= 'z') {
			// Make it an upper case and then put it in the right array position (-= 0x20 + 0x41);
			cur -= 0x61;
		// Uppercase
		} else if (cur >= 'A' && cur <= 'Z') {
			cur -= 0x41;
		// Numbers
		} else if (cur >= '0' && cur <= '9') {
			// Normalize the number and put it at the right array position (-= 0x30 - 0x1A);
			cur -= 0x16;
		// Space
		} else if (cur == ' ') {
			usleep(PAUSE_TIME);
			continue;
		// Period
		} else if (cur == '.') {
			usleep(PAUSE_TIME * 2);
			continue;
		// Ignore unknown chars
		} else {
			printf("Failed to play char '%c'\n", cur);
			continue;
		}
		
		printf("alphabet index: %d\n", cur);
		play(alphabet[cur]);
	}
	
	printf("\nFreeing allocated memory\n");
	free_data();
	printf("KBYE\n");
	exit(1);
}

