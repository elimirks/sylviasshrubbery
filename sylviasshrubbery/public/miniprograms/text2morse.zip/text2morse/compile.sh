#!/bin/bash

# You will just need SDL_mixer to compile this program.

gcc -std=c99 `sdl-config --cflags --libs` -lSDL_mixer -g main.c -o text2morse

