function isLoginPage() {
	var forms = document.getElementsByTagName("form");
	for (var i = 0; i < forms.length; i++) {
		var form = forms[i];
		var contents = form.innerHTML;
		if (contents.search(/(password)/i) > 0) {
			return true;
		}
	}
	return false;
}

if (isLoginPage()) {
	var path = chrome.extension.getURL("portal_song.mp3");
	new Audio(path).play();
}

